classdef AccountState
  enumeration
    Open, Closed
  end
end